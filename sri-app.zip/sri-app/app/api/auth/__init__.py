"""
Authentication module
"""
from .controller import api