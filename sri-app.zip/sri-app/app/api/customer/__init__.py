"""
Customer module
"""
from .controller import api