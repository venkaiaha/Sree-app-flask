DESIGN DOCUMENTATION – SRI ACCOUNTING

REST API / DATABASE MODELS

NEW COMPANY REGISTRATION

Sl	Fields		Sub Field	Type		Validation Type		Comments
1.	ABN						TEXT, INDEXED	String	
2.	ACN						TEXT, INDEXED	String	
3.	TFN						TEXT, INDEXED	String	
4.	COMPANY NAME			TEXT, INDEXED
5.	OWNER NAME				TEXT, INDEXED
6.	ADDRESS BUSINESS
				STREET		TEXT			--	
				CITY		TEXT			--	
				STATE/TERRITORY	TEXT		--	
				POSTCODE	TEXT			String	
7.	ADDRESS REGISTERED
				STREET		TEXT			--	
				CITY		TEXT			--	
				STATE/TERRITORY	TEXT		--	
				POSTCODE	TEXT			String	
8.	FORMATION DATE			DATE TIME		DATE TIME	
9.	GST						BOOLEAN			options	
10.	PAYER					BOOLEAN			options	
11.	BUSINESS NAME			TEXT
12.	BAS PERIOD								MONTHLY/		Dropdown array
											QUARTERLY/
											ANNUALY			
13.	CREATED AT				DATE TIME						Auto Created
14.	UUID					TEXT, PRIMARY KEY				Auto Created

 
NEW CUSTOMER REGISTRATION:

Sl	Fields	Sub Field	Type		Validation Type				Comments
1.	SURNAME				TEXT			Alphabet	
2.	FIRST NAME			TEXT, INDEXED	Alphabet	
3.	Salutation						Mr. / Mrs. /Ms /Miss/Dr		Dropdown array	
4.	DOB					DATE			date	
5.	TFN					TEXT, INDEXED	Number	
6.	ABN					TEXT			Number	
7.	ACN					TEXT			Number	
8.	DATE OF JOINING		DATE			date	
9.	PHONE				TEXT			Numbers	
10.	EMAIL				TEXT, INDEXED	email	
11.	EXTERNAL CUSTOMER	BOOLEAN		Yes / no	
12.	SPOUSE
		FIRST NAME		TEXT		Alphabet	
		LAST NAME		TEXT		Alphabet	
		DOB				DATE		date	
		EMAIL			email	
		MOBILE			Number	
		TFN				TEXT	
13.	NO OF CHILD			TEXT		Number	
14.	BAS PERIOD				MONTHLY/QUARTERLY/ANNUALY			Dropdown Array	
15.	CREATED AT			DATE TIME									Auto created
16.	UUID				TEXT, PRIMARY KEY							Auto created

 
STAFF REGISTRATION

Sl		Fields		Sub Field	Type			Validation Type			Comments
1.		SURNAME					TEXT
2.		FIRST NAME				TEXT, INDEXED
3.		ROLE		Operator / 
					Book keeper / 
					Accountant / 
					Admin												Dropdown Array	
4.		Employ id				Text, INDEXED	--	
5.		Created at				DATE TIME								Auto created
6.		UUID					DATE TIME, PRIMARY KEY					Auto created

 

TYPES TABLE

Sl	Field	Sub Field	Type	Validation type	Comments
1.		_id		PRIMARY KEY	AUTO INCREASING	Auto created
2.		Documents		TEXT Array(set)	--	New type is appended to array created by admin
Eg: [“bank_statement”, “form-16”, ‘house_rent_doc”]
3.		Status		TEXT Array(set)	--	New type is appended to array created by admin
Eg: [“bookkeeper_inreview”, “lodged”, “completed”, “acknowledged”]
4.		Customer_fields		TEXT Array(set)	--	New customer registration fields can be added
5.		Company fields		TEXT Array(set)	--	New company registration fields can be added
6.		STATE/TERRITORY		TEXT Array(set)	--	Ex. [Queens Land, “New south wales”]


 

DATA BASE MODELS (FREQUENTLY CHANGED)

STAFF TIME TRACKING

Sl	Field	Sub Field	Type	Validation type	Comments
1.		_id		PRIMARY KEY	AUTO INCREASING	Auto created
2.		Staff UUID 		--, INDEXED		Auto created
3.		Role		--		Auto created
4.		Event		text	Year_bas type_options	Ex. 2019_monthly_feb
2019_qtrly_q1
2019_annual_a
5.		Time spent		Hours/ min	Hours / min	
6.		Submitted at		timestamp	Date time	Auto created
7.		Company / customer UUID		--, INDEXED		Auto created




 
STATUS TABLE

Sl	Field	Sub Field	Type	Validation type	Comments
1.		_id		PRIMARY KEY	AUTO INCREASING	Auto created
2.		CUSTOMER / COMPANY UUID		--	INDEXED	Auto created
3.		_type		Company/customer	options	
4.		Event		text	Year + bastype +
options	Eg:
“2019_monthly_feb”
“2019_qtrly_q1”
“2019_annual_end”
5.		status		text	Role + options	Eg:
“operator_pending”
“bookkeeper_inreview”
“accountant_pending”
“not lodged”
6.		status_time		Date time		Auto created
7.		note		text	--	
8.		allocated to		staff role		
9.		allocated to  staff		Staff id		
10.		allocation id		id		Auto created

 
REST API’S

API :  Adding new customer
Swagger documentation Example:
POST	/api/v1/customer/	Add a new customer 
Parameters	
Parameter	Value	Description	Parameter type	Model
				
body		New customers to be added to the database	Body	{“abn”:”546 376 834”, “acn”: “1234 3434 ”, “company_name”:”Mnc Company ltd”, “owner_name”: “Abc”, “address_business”:{“street”: “xxxxx”, “city”:”xxxx”, “state”:”south wales”,”postcode”:”21334”}, “formation_date”:”xxxxx”, “gst”:true, “payer”:true, “business_name”:”xxxxx”, “bas_period”:”monthly”, “createdat”:”xxxxxx”, “_id”:”se455sh-34vgrrr4-454df3g”}
				
					
	Parameter content type	application/json			
					
					
Response Messages
Http Status Code	Reason	Response Model		Headers
200		{“msg”: “success”, “error”: null, “info”:null }		
				

 
OPERATOR SCREEN

1.	POST  /api/v1/customer 		application/json		Adding new customers
2.	PUT	   /api/V1/customer		application/json 		edit / make changes to customer details
3.	GET    /api/v1/customer/<some id>				Retrieve all / required customers 										(optional)

4.	POST  /api/v1/company		application/json 		Adding new companies
5.	PUT	   /api/v1/company		application/json 		edit / make changes to company details
6.	GET	   /api/v1/company/<some id>				Retrieve all / required companies 										(optional)

7.	POST    /api/v1/upload/<type of doc>	Form data		upload documents
8.	PATCH /api/v1/upload/<type of doc>	Form data		overwrite existing documents
9.	GET	     /api/v1/download/<doc type>	Form data		download documents

10.	GET	    /api/v1/allocate/<staff role>/<id>			checks whether previously allocated 									and allocates work to specific employ
11.	DELETE /api/v1/allocate/<allocation id>				removes  allocation to the employ
(optional)

12.	GET   /api/v1/allocation/status					get the data related to status

BOOK KEEPER / ACCOUNTANT SCREEN
 
1.	POST  /api/v1/submit/customer	application/json		submits work with status and comments

2.	POST  /api/v1/submit/company	application/json		submits work with status and comments

3.	GET    /api/v1/status/staff					gets the status of his own	/ during login or 									later
	
4.	GET   /api/v1/process/<allocation_id>				starts processing of the selected as a result he 								would be able to verify documents and 									submit (change the status)

ADMIN

1.	POST     /api/v1/adduser		Form-data		adds users to the database

2.	DELETE /api/v1/deluser		application/json		removes users from databases

3.	GET	      /api/v1/track/customer/<id>				tracks a particular customer’s claim / returns

4.	GET      /api/v1/track/company/<id>				tracks a particular customer’s claim / returns

5.	POST /api/v1/add/regfields/<customer/company>  app/json	adds new field to customer/company 									registration

6.	POST /api/v1/add/docfields/<customer/company> app/json	adds new field to customer/company 									documents (checklist)

7.	POST /api/v1/add/statusfields					adds new status filed to database
					

 
COMMON
Login

1.	POST   /api/v1/login			basicAuth		Login and create session for staff (operator / 										bookkeeper / accountant / admin)

2.	GET   /api/v1/logout						log out from current session

Search (Based on TEXT INDEXES / elastic)

3.	GET     /api/v1/company/<search text>				Elastic search for  companies

4.	GET     /api/v1/customer/<search text>				Elastic search for customers

Pulldown menu options

5.	GET	/api/v1/states						Lists all states

6.	GET   	/api/v1/doclist						lists all document check lists

7.	GET   	/api/v1/statuslist					lists all statuses
						
8.	GET  	/api/v1/regfields/<company/customer>			lists all company / customer registration fileds


OTHER SERVICES
Mail service

	A separate service which runs continuously which tracks the status of the customer / company status for the current state for current period and sends mails.

 
Project Tree structure

.
└── sri-accounting
    ├── app
    │   ├── api
    │   │   ├── auth
    │   │   │   ├── controller.py
    │   │   │   ├── __init__.py
    │   │   │   ├── models.py
    │   │   │   ├── __pycache__
    │   │   │   │   ├── controller.cpython-36.pyc
    │   │   │   │   ├── __init__.cpython-36.pyc
    │   │   │   │   └── models.cpython-36.pyc
    │   │   │   └── response.py
    │   │   ├── company
    │   │   │   ├── controller.py
    │   │   │   ├── __init__.py
    │   │   │   └── models.py
    │   │   ├── customer
    │   │   │   ├── controller.py
    │   │   │   ├── __init__.py
    │   │   │   └── models.py
    │   │   ├── __init__.py
    │   │   └── staff
    │   │       ├── controller.py
    │   │       ├── __init__.py
    │   │       └── models.py
    │   ├── __init__.py
    │   └── requirements.txt
    ├── config.py
    ├── Makefile
    ├── manage.py
    ├── __pycache__
    │   └── config.cpython-36.pyc
    └── requirements.txt



SAMPLE UI PAGES

 

 

 

 
